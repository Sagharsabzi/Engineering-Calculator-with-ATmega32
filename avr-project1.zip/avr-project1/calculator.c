#include <mega16.h>
#include <delay.h>
#include <lcd.h>
#include <stdlib.h>
#include <math.h>

#asm
   .equ __lcd_port=0x18
#endasm
/////////////////////////////////////////////////
int readKeypad(void);
float MainFunction(void);
void scientificCalculate(void);
void calculate(void);
void displayOperation(int,int);
float calculateExponential(int);
/////////////////////////////////////////////////
float a = 0 , b = 0 , c = 0 , t;
int i ;
char keyPressed=0 , lcd[25] , operatorSelected   ;
/////////////////////////////////////////////////

void main(void) {
    DDRB = 0x0F;
    DDRC = 0x07;
    DDRD = 0x0F;

    lcd_init(16);

    while (1) {
        MainFunction();
    }
}

/////////////////////////////////////////////////

float MainFunction(void) {
    int loopFlag = 1;
    keyPressed = readKeypad();

    if (keyPressed == 15) {
        a = b = c = 0;
        lcd_clear();
        return 0;
    }

    if (keyPressed < 10) {
        a = (a * 10) + keyPressed;
        itoa(keyPressed, lcd);
        lcd_puts(lcd);
        delay_ms(50);
    } else if (keyPressed >= 10 && keyPressed < 16) {
        if (keyPressed == 15) {
            a = b = c = 0;
            lcd_clear();
            return 0;
        }
        operatorSelected = keyPressed;
        displayOperation(keyPressed, 1);

        while (loopFlag) {
            keyPressed = readKeypad();
            if (keyPressed == 15) {
                a = b = c = 0;
                lcd_clear();
                return 0;
            }

            if (keyPressed < 10) {
                b = (b * 10) + keyPressed;
                itoa(keyPressed, lcd);
                lcd_puts(lcd);
                delay_ms(50);
            } else if (keyPressed == 14) {
                lcd_putchar('=');
                calculate();
                loopFlag = 0;
            }
        }
    } else if (keyPressed > 15) {
        lcd_clear();
        a = b = c = 0;
        displayOperation(keyPressed, 2);
        operatorSelected = keyPressed;
        loopFlag = 1;

        while (loopFlag) {
            keyPressed = readKeypad();

            if (keyPressed == 15) {
                a = b = c = 0;
                lcd_clear();
                return 0;
            }

            if (keyPressed < 10) {
                a = (a * 10) + keyPressed;
                itoa(keyPressed, lcd);
                lcd_puts(lcd);
                delay_ms(50);
            } else if (keyPressed == 14) {
                lcd_putchar('=');
                scientificCalculate();
                loopFlag = 0;
            }
        }
    }
    return 0;
}

/////////////////////////////////////////////////
void calculate(void){                                          
if(operatorSelected == 10)c = a / b ;
if(operatorSelected == 11)c = a * b ;
if(operatorSelected == 12)c = a - b ;
if(operatorSelected == 13)c = a + b ;
ftoa(c , 3 , lcd);            
lcd_puts(lcd);
delay_ms(100);
}
/////////////////////////////////////////////////
float calculateExponential(int exponent) {
    float result = 1;
    for (i = 0; i < exponent; i++) {
        result *= 2.71728;
    }
    return result;
}
/////////////////////////////////////////////////
void scientificCalculate(void){
t = (3.1415926535897932384626433832795/180)*a ;
if(operatorSelected == 16)c = sin(t) ;
if(operatorSelected == 17)c = cos(t) ;
if(operatorSelected == 18)c = tan(t) ;
if(operatorSelected == 19)c = 1/tan(t) ;
if(operatorSelected == 20)c = asin(t) ;
if(operatorSelected == 21)c = acos(t) ;
if(operatorSelected == 22)c = log(a) ;
if(operatorSelected == 23)c = sqrt(a) ;
if(operatorSelected == 24)c = calculateExponential(a) ;
ftoa(c , 3 , lcd);            
lcd_puts(lcd);
delay_ms(100);
}
/////////////////////////////////////////////////
void displayOperation(int operationCode, int mode) {
    if (mode == 1) {
        switch (operationCode) {
            case 10: lcd_putchar('/'); break;
            case 11: lcd_putchar('*'); break;
            case 12: lcd_putchar('-'); break;
            case 13: lcd_putchar('+'); break;
        }
        delay_ms(100);
    }

    if (mode == 2) {
        switch (operationCode) {
            case 16: lcd_putsf("sin "); break;
            case 17: lcd_putsf("cos "); break;
            case 18: lcd_putsf("tan "); break;
            case 19: lcd_putsf("cot "); break;
            case 20: lcd_putsf("asin"); break;
            case 21: lcd_putsf("acos"); break;
            case 22: lcd_putsf("log "); break;
            case 23: lcd_putsf("Sqrt "); break;
            case 24: lcd_putsf("exp "); break;
        }
        delay_ms(100);
    }
}

/////////////////////////////////////////////////
int readKeypad(void) {
    char keyDetected = 1;
    while (keyDetected) {
        PORTD.0 = 1; PORTD.1 = 0; PORTD.2 = 0; PORTD.3 = 0;
        if (PIND.4 == 1) { return 7; keyDetected = 0; delay_ms(50); }
        if (PIND.5 == 1) { return 8; keyDetected = 0; delay_ms(50); }
        if (PIND.6 == 1) { return 9; keyDetected = 0; delay_ms(50); }
        if (PIND.7 == 1) { return 10; keyDetected = 0; delay_ms(50); }

        PORTD.0 = 0; PORTD.1 = 1; PORTD.2 = 0; PORTD.3 = 0;
        if (PIND.4 == 1) { return 4; keyDetected = 0; }
        if (PIND.5 == 1) { return 5; keyDetected = 0; }
        if (PIND.6 == 1) { return 6; keyDetected = 0; }
        if (PIND.7 == 1) { return 11; keyDetected = 0; }

        PORTD.0 = 0; PORTD.1 = 0; PORTD.2 = 1; PORTD.3 = 0;
        if (PIND.4 == 1) { return 1; keyDetected = 0; }
        if (PIND.5 == 1) { return 2; keyDetected = 0; }
        if (PIND.6 == 1) { return 3; keyDetected = 0; }
        if (PIND.7 == 1) { return 12; keyDetected = 0; }

        PORTD.0 = 0; PORTD.1 = 0; PORTD.2 = 0; PORTD.3 = 1;
        if (PIND.4 == 1) { return 15; keyDetected = 0; }
        if (PIND.5 == 1) { return 0; keyDetected = 0; }
        if (PIND.6 == 1) { return 14; keyDetected = 0; }
        if (PIND.7 == 1) { return 13; keyDetected = 0; }

        PORTC.0 = 1; PORTC.1 = 0; PORTC.2 = 0;
        if (PINC.5 == 1) { return 16; keyDetected = 0; }
        if (PINC.6 == 1) { return 17; keyDetected = 0; }
        if (PINC.7 == 1) { return 18; keyDetected = 0; }

        PORTC.0 = 0; PORTC.1 = 1; PORTC.2 = 0;
        if (PINC.5 == 1) { return 19; keyDetected = 0; }
        if (PINC.6 == 1) { return 20; keyDetected = 0; }
        if (PINC.7 == 1) { return 21; keyDetected = 0; }

        PORTC.0 = 0; PORTC.1 = 0; PORTC.2 = 1;
        if (PINC.5 == 1) { return 22; keyDetected = 0; }
        if (PINC.6 == 1) { return 23; keyDetected = 0; }
        if (PINC.7 == 1) { return 24; keyDetected = 0; }

        keyDetected = 1;
    }
}

